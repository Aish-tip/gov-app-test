export const environment = {
  production: true,
  // api_base_url: 'http://65.2.11.204:3000/api'
  api_base_url: 'http://13.232.237.138:3000/api'

};
